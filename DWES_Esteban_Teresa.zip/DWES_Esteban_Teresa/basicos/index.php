<!DOCTYPE html>
<html lang="en">
<head>
<?php include "../includes/metadata2.php"; ?>
</head>
<body>
<?php include "../includes/header2.php"; ?> <!-- Aquí se incluye el contenido.php -->
<?php include "../includes/menu2.php"; ?>


<div class="caja">
    <?php include "../includes/nav_basicos.php"; ?>
    <main>
     <h3>Zona de ejercicios basicos</h3>
     <p>Aqui se pueden consultar desde el menu de navegacion algunos de los ejercicios realizados
        en el modulo sobre programacion basica
     </p>
</main>
    <?php include "../includes/aside2.php"; ?>
</div>
<?php include "../includes/footer2.php"; ?>
</body>
</html>