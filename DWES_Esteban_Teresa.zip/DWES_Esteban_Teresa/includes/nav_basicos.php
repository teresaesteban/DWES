<nav>
  Menu
  <br>
  <a href="../index.php">Inicio</a><br>
  <a href="ej1.php">1.Test PHP</a><br>
  <a href="ej2.php">2.Conversor €</a><br>
  <a href="ej3.php">3.Cambio Divisas</a><br>

</nav>