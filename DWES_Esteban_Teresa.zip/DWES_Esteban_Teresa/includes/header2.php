<header>
    <img src="../images/logoCPI.png" alt="No se ve">
   <h1 class="texto">DESARROLLO WEB EN ENTORNO SERVIDOR</h1>

</header>