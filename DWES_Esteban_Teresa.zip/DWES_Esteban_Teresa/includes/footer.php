<footer>
  <div class="redesSociales">
    <a href="https://www.facebook.com" target="_blank"><img src="images/facebook.png" alt="Facebook"></a>
    <a href="https://www.twitter.com" target="_blank"><img src="images/twitter.png" alt="Twitter"></a>
    <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.png" alt="Instagram"></a>
    <a href="https://discord.com/" target="_blank"><img src="images/discord.png" alt="Discord"></a>
    <a href="https://www.linkedin.com/" target="_blank"><img src="images/linkedin.png" alt="Linkedin"></a><br>
  </div>
</footer>