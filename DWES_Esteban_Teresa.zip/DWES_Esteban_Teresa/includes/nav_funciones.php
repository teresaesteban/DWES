<nav>
  Menu
  <br>
  <a href="../index.php">Inicio</a><br>
  <a href="ej1.php">1.Tablas HTML</a><br>
  <a href="ej2.php">2.Cambio divisas</a><br>
  <a href="ej3.php">3. Nº primos</a><br>
  <a href="ej4.php">4.Nº perfectos</a><br>
  <a href="ej5.php">5, Circulos</a><br>
</nav>