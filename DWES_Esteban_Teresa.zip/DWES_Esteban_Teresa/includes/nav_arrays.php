<nav>
  Menu
  <br>
  <a href="../index.php">Inicio</a><br>
  <a href="ej1.php">1.Array aleatorio</a><br>
  <a href="ej2.php">2.Ordenacion</a><br>
  <a href="ej3.php">3.Liga futbol</a><br>
  <a href="ej4.php">4.Funciones arrays</a><br>
  <a href="ej5.php">5.Funciones string</a><br>
  <a href="ej6.php">6.Palindromos</a><br>
  <a href="ej7.php">7.Matrices</a><br>
</nav>