<aside>
<a href="https://www.php.net/" ><img src="images/php.png" alt="PHP"></a>
<a href="https://www.w3schools.com/" ><img src="images/W3.png" alt="W3Schools"></a>
<a href="https://chat.openai.com/" ><img src="images/ChatGPT-Logo.png" alt="chatgpt"></a>
</aside>