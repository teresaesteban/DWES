<div class="menu">
  <a href="./index.php">Inicio</a>
  <a href="basicos/index.php">Basicos</a>
  <a href="funciones/index.php">Funciones</a>
  <a href="arrays/index.php">Arrays</a>
  <a href="bdjardineria/index.php">BBDD</a>
</div>