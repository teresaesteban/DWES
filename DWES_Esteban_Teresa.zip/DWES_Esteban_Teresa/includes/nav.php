<nav>
  <div class="central">
  MENU
</div>
  <br>
  <a href="./index.php">Inicio</a><br>
  <a href="basicos/index.php">Basicos</a><br>
  <a href="funciones/index.php">Funciones</a><br>
  <a href="arrays/index.php">Arrays</a><br>
  <a href="bdjardineria/index.php">BBDD</a><br>
</nav>