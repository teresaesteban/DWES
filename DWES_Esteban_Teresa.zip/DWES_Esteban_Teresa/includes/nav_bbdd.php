<nav>
  Menu
  <br>
  <a href="../index.php">Inicio</a><br>
  <a href="ej1.php">1.Lista Clientes</a><br>
  <a href="ej2.php">2.Productos gama</a><br>
  <a href="ej3.php">3.Estadistica</a><br>
  <a href="ej4.php">4.Clientes por pais</a><br>
  <a href="ej5.php">5.Insertar cliente</a><br>
  <a href="ej6.php">6.Modificar cliente</a><br>
  <a href="ej7.php">7.Borrar cliente</a><br>
  <a href="ej8.php">8.Pedidos cliente</a><br>
  <a href="ej9.php">9.Importe pedidos</a><br>
</nav>