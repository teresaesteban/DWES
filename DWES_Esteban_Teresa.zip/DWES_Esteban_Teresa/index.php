<!DOCTYPE html>
<html lang="en">
<head>
<?php include "includes/metadata.php"; ?>
</head>
<body>
<?php include "includes/header.php"; ?> <!-- Aquí se incluye el contenido.php -->
<?php include "includes/menu.php"; ?>
<div class="caja">
<?php include "includes/nav.php"; ?>
<main>
puro texto bb

</main>
<?php include "includes/aside.php"; ?>
</div>
<?php include "includes/footer.php"; ?>
</body>
</html>